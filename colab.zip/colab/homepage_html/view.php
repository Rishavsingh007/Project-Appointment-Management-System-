<!DOCTYPE html>
<html>
<head>
   <title>Image Gallery</title>
   <style>
      /* Define the grid container */
      .gallery {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
         grid-gap: 20px;
      }

      /* Define the grid item */
      .gallery-item {
         display: flex;
         justify-content: center;
         align-items: center;
         height: 250px;
         background-color: #f1f1f1;
         border: 1px solid #ccc;
      }

      /* Define the image */
      .gallery-item img {
         max-width: 100%;
         max-height: 100%;
         object-fit: cover;
      }
   </style>
</head>
<body>
   <h1>Image Gallery</h1>
   <div class="gallery">
      <?php
         // Include the database configuration file
         include 'dbConfig.php';

         // Fetch all images from the database
         $query = $db->query("SELECT * FROM images ORDER BY uploaded_on DESC");

         if($query->num_rows > 0){
            while($row = $query->fetch_assoc()){
               $imageURL = 'img/'.$row["file_name"];
               echo '<div class="gallery-item"><img src="'.$imageURL.'" alt="'.$row["file_name"].'"></div>';
            }
         }else{
            echo "<p>No images found</p>";
         }
      ?>
   </div>
</body>
</html>
