<!DOCTYPE html>
<html>

<head>
  
  <title>Doctor Directory</title>
  <style>
    a {
      text-decoration: none;
    }

    * {
      box-sizing: border-box;
    }
    
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      /* background-color:orange; */
    }
    
    .card {
      width: calc(33.33% - 20px);
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 20px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      background-color:white;

    }
    
    .card h2 {
      margin: 0;
    }
    
    .card img {
      max-width: 100%;
      height: auto;
      margin-bottom: 10px;
    }
    h1{
    
      text-align:center;
    }
    .btn {
  display: inline-block;
  padding: 0.9rem 1.9rem;
  color: #fff !important;
  background-color: #f4aa64;
  border-radius: 16px;
  text-transform: capitalize;
  transition: 0.3s;
}

.btn:hover {
  background-color: #d9df5b;
  transform: scale(1) !important;
}
  </style>
</head>
<body>
<h1>Our Doctors</h1>
  <div class="container">

    <?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ams";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve doctor information with specialties from database
    $sql = "SELECT doctor.docname, doctor.docemail, specialties.sname, doctor.image
    FROM doctor
    INNER JOIN specialties
    ON doctor.specialties = specialties.id;";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        ?>
        <div class="card">
          <?php
          // Check if image data is available
          if (!empty($row["image"])) {
            // Output image tag with online image link
            echo "<img src='" . $row["image"] . "' alt='Doctor Image' />";
          }
          ?>
          <h2><?php echo $row["docname"]; ?></h2>
          <p><strong>Specialty:</strong> <?php echo $row["sname"]; ?></p>
          <a href="../login.php" class="btn">Book Appointment</a>

        </div>
        <?php
      }
    } else {
      echo "<p>No doctors found.</p>";
    }

    // Close database connection
    $conn->close();
    ?>
  </div>
</body>
</html>
